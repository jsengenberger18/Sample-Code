package listPack;

public class OrderQueue
{
	// Queue Contents
	private int numOrders;
	private int capacity;
	
	// Queue Links
	private Order front;
	private Order back;
	
	// Constructors
	public OrderQueue (int inCapacity)
	{
		front = null;
		back = null;
		numOrders = 0;
		capacity = inCapacity;
	}
	
	// Getters
	public Order getFront()
	{
		return front;					// next in queue
	}
	public Order getBack()
	{
		return back;
	}
	public int getNumOrders()
	{
		return numOrders;
	}
	public int getCapacity()
	{
		return capacity;
	}
	
	// Size Checks
	public boolean isFull()
    {
		if (numOrders == capacity)
		{
			return true;
		}
    	return false;
    }
	public boolean isEmpty()
	{
		if (numOrders == 0)
		{
			return true;
		}
		return false;
	}
	
	// Queue Management
	protected boolean contains(int orderNum)
	{
		Order toBack = front;
		
		while (toBack != null)
		{
			if (toBack.getOrderNum() == orderNum)
			{
				return true;	// confirm order number exists
			}
			
			toBack = toBack.getNextOrder();
		}
		
		return false;
	}
	public boolean addToBack(Order newOrder)
	{
		if (!this.isFull())					// if has room
		{
			if (back != newOrder)				// if new order
			{
				if (front == null)					// #1: initialize
				{
					back = newOrder;
					front = back;
				}
				else if (front == back)				// #2: separate
				{
					back = newOrder;
					front.setNextOrder(back);
				}
				else								// #3: add to back
				{
					back.setNextOrder(newOrder);
					back = newOrder;
				}
				
				numOrders++;
			}
			
			return true;						// confirm
		}
		else
		{
			return false;					// else full
		}
	}
	public Order removeFront()
	{
		Order toRemove = null;					// assume empty queue

		if (!this.isEmpty())						// if has entries
		{
			toRemove = front;
			front = toRemove.getNextOrder();			// move front
			
			toRemove.setNextOrder(null);				// disconnect
			
			numOrders--;								// update order
			if (front == null)
			{
				back = null;
			}
		}

		return toRemove;							// confirmation
	}
	public Order clear()
	{
		Order toRemove = front;		// remove front
		back = null;				// disconnect
		front = null;
		
		numOrders = 0;				// update
		return toRemove;			// confirmation
	}
	
	// Miscellaneous
	public Order [] toArray()
	{
		Order [] unsorted = new Order [numOrders];

		if (!(this.isEmpty()))								// Front -> Back
		{
			Order temp = front;
			
			for (int index = 0; index < numOrders; index++)
			{
				unsorted[index] = temp;
				temp = temp.getNextOrder();
			}
		}
		
		return unsorted;
	}
}