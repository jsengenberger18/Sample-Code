package listPack;

public class Order
{
	// Order Contents
	private String customer;
	private int orderNum;
	private double totalCost;
	private int numItems;
	
	// Queue Links
	private Order nextOrder;
	private Item cart;
	
	// Constructors
	protected Order (String inLastName, int inOrderNum)
	{
		customer = inLastName;
		orderNum = inOrderNum;
		totalCost = 0.0;
		numItems = 0;
		
		nextOrder = null;
		cart = null;
	}
	
	// Getters
	protected String getCustomer()
	{
		return customer;
	}
	protected int getOrderNum()
	{
		return orderNum;
	}
	protected double getTotalCost()
	{
		return totalCost;
	}
	protected int getNumItems()
	{
		return numItems;
	}
	protected Order getNextOrder()
	{
		return nextOrder;
	}
	protected Item getCart()
	{
		return cart;
	}
	
	// Setters
 	protected void setNextOrder(Order nextNode)
	{
		nextOrder = nextNode;
	}
	
	// Size Checks
	protected boolean isFull()
    {
		if (numItems == 10)		// hard-coded default size
		{
			return true;
		}
    	return false;
    }
	protected boolean isEmpty()
	{
		if (numItems == 0)
		{
			return true;
		}
		return false;
	}
	
	// Queue Management
	protected Item contains(Item toCheck)
	{
		Item toBack = cart;
		while (toBack != null)
		{
			if (toBack.getItemName() == toCheck.getItemName())
			{
				return toBack;	// return existing item in cart
			}
			
			toBack = toBack.getNextItem();
		}
		
		return null;
	}
	protected boolean enqueue(Item newItem)
	{
		if (!this.isFull())						// if has room
		{			
			if (cart == null)						// initialize
			{
				cart = newItem;
			}
			else									// typical
			{
				Item toBack = contains(newItem);
				
				if (toBack != null)						// existing item
				{
					toBack.incrementQuantity();
				}
				else									// new item
				{
					toBack = cart;
					while (toBack.getNextItem() != null)
					{
						toBack = toBack.getNextItem();		// add to back
					}
					toBack.setNextItem(newItem);
				}
			}
			
			totalCost += newItem.getPrice();		// update order
			numItems++;
			
			return true;							// confirmation
		}
		else
		{
			return false;						// else full
		}
	}
	protected Item dequeue()
	{
		Item toRemove = null;					// assume empty queue

		if (!this.isEmpty())					// if has entries
		{
			toRemove = cart;
			cart = toRemove.getNextItem();			// move front
			
			toRemove.setNextItem(null);				// disconnect
			
			totalCost -= toRemove.getPrice();		// update order
			numItems--;
		}

		return toRemove;						// confirmation
	}
	protected Item clear ()
	{
		Item toRemove = cart;		// remove cart (front)
		cart = null;				// disconnect
		
		totalCost = 0;				// update
		numItems = 0;
		return toRemove;			// confirmation
	}
	
	// Miscellaneous
	public Item validateItem(String userEntry, final Item [] PRODUCTS)
	{
		for (Item product : PRODUCTS)
		{
			if (userEntry.equals(product.getItemName()))
			{
				return new Item(product);
			}
		}
		
		if (!(userEntry.equals("Done")))
		{
			System.out.println("Invalid Entry. Try again.");
		}
		
		return null;
	}
}
