package listPack;

import java.util.Scanner;

public class Main
{
	/* 
	 * Prompts the user with an Order Menu of options of
	 * modify order, new order, show order database,
	 * remove order, clear database, and quit.
	 * 
	 * Provides an Item Menu as well to modify the contents of an order,
	 * which includes add item, show cart,
	 * remove item, clear cart, and done.
	 * 
	 * The order list is a hybrid queue and deque,
	 * where some additional visibility is added
	 * while keeping the list as functionally a queue.
	 * 
	 * The item list is a hybrid of a queue and a priority queue
	 * where it remains a queue except the enqueue
	 * of an existing item simply increases its quantity.
	 */
	
	// Initialize Constants
	static final int DEFAULT_CAPACITY = 10;
	static final Item [] PRODUCTS =
		{
			new Item (5.99, "Beef"),
			new Item (9.99, "Lamb"),
			new Item (8.99, "Feta"),
			new Item (9.99, "Cheddar"),
			new Item (6.99, "Cholula"),
			new Item (0.99, "Garlic"),
			new Item (3.99, "Tomatoes"),
			new Item (2.99, "Taziki"),
			new Item (2.99, "Tortillas"),
			new Item (4.99, "Pita"),
			new Item (1.99, "Pene"),
			new Item (1.99, "Spagetti"),
			new Item (6.99, "Pesto"),
			new Item (4.99, "Marinara")
		};
	
	public static void main(String[] args)
	{
		// Prepare User Input
		Scanner stringScnr = new Scanner(System.in);
		String customer = "";
		
		// Prepare Database Queue
		OrderQueue orderDB = new OrderQueue(DEFAULT_CAPACITY);	
		Order myOrder = null;
		int orderNum = 0;
				
		// Start Ordering Process
		String choice = "2";
		boolean again = true;
		
		System.out.println("Order Database");		
		do
		{
			// Order Menu / Selection at Bottom
			// ------------------------------------------
			// 1 - Modify: Modify Order's Item Queue
			// 2 - New: Generate New Order
			// 3 - Show: Print Sorted & Unsorted
			// 4 - Remove: Remove from Order Queue
			// 5 - Clear: Wipe Database
			// 6 - Quit: Close
			// ------------------------------------------
			
			switch (choice)
			{
				case "1":	// Modify Order
					System.out.println("Order #: " + myOrder.getOrderNum());
										
					myOrder = modifyOrder(myOrder, stringScnr);
					
					System.out.print("Save Order? (Yes / No): ");
					if (!(stringScnr.nextLine().equals("Yes")))
					{
						break;
					}
					else	// Save Order to OrderDB
					{
						orderDB.addToBack(myOrder);
						Display.sortOrders(orderDB);
						
						System.out.print("New Order? (Yes / No): ");
						if (!(stringScnr.nextLine().equals("Yes")))
						{
							break;
						}
					}
					// Proceed to New
					
				case "2":	// Generate New Order
					System.out.println();
					System.out.println("--------------------");
					System.out.println("New Order");
					System.out.println("--------------------");
					System.out.println();
					
					do
					{
						orderNum = (int)(Math.random()*100+1);
						
					} while (orderDB.contains(orderNum));
					
					System.out.print("Customer Last Name: ");
					customer = stringScnr.nextLine();
					
					myOrder = new Order (customer, orderNum);
					
					break;
					
				case "3":	// Sort & Print OrderDB
					System.out.println();
					System.out.println("--------------------");
					
					if (!(orderDB.isEmpty()))
					{
						Display.sortOrders(orderDB);
						Display.printUnsortedOrders();
						Display.printByCustomer();
						Display.printByOrderNum();
					}
					else
					{
						System.out.println("Order Database Empty");
						System.out.println("--------------------");
					}
										
					break;
					
				case "4":	// Remove Order from OrderDB
					Order removed = orderDB.removeFront();
					if (removed != null)
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Removed Order");
						System.out.println("--------------------");
						System.out.println();
						
						Display.printOrder(removed);
						
						System.out.println();
						System.out.println("--------------------");

						Display.sortOrders(orderDB);
					}
					else
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Order Database Empty");
						System.out.println("--------------------");

					}
					break;
					
				case "5":	// Clear Order Database
					Display.printOrderDB(orderDB.clear());
					Display.sortOrders(orderDB);
					break;
					
				case "6":	// Quit Program
					again = false;
					System.out.println("Closing...");
					stringScnr.close();
					continue;
					
				default:
					System.out.println();
					System.out.println("--------------------");
					System.out.println("Invalid Entry. Try Again.");
					System.out.println("--------------------");
					break;
			}
			
			Display.showMainMenu();
			choice = stringScnr.nextLine();
			System.out.println("--------------------");
			
		} while (again == true);
	}
	
	// Adds one or more items to the current order, pending user input
	private static Order modifyOrder (Order myOrder, Scanner stringScnr)
	{		
		String choice = "";
		Item newItem = null;
		boolean done = false;
		
		if (myOrder.getCart() != null)			// Print Order Contents
		{
			System.out.println();
			System.out.println("Order Contents");
			Display.printCart(myOrder.getCart());
			System.out.println("Order Total: $" + String.format("%.2f", myOrder.getTotalCost()));
		}
		
		do
		{
			// Item Menu
			// ------------------------------------------
			// Add: Add an Item
			// Show: Print Cart
			// Remove: Remove an Item
			// Clear: Wipe the Order
			// ------------------------------------------
			
			Display.showItemMenu();
			choice = stringScnr.nextLine();
			System.out.println("--------------------");						
						
			switch (choice)
			{
				case "1":							// Add an Item
					
					Display.showProductMenu(PRODUCTS);
					System.out.println("Order #: " + myOrder.getOrderNum());
										
					do								// Fill Order
					{
						do								// Retrieve Item
						{
							newItem = null;
							System.out.println();
							System.out.print("Selection (NAME ONLY): ");
							
							choice = stringScnr.nextLine();
							done = choice.equals("Done");
							newItem = myOrder.validateItem(choice, PRODUCTS);
							
						} while (newItem == null && !done);			// Confirm
						
						if (!done)
						{
							if (myOrder.enqueue(newItem) == true)		// Add to Cart
							{
								System.out.print("Item Details: ");
								Display.printItem(myOrder.contains(newItem));
							}
							else
							{
								System.out.println("Cart Full");
							}
						}
					} while(!done);
					
					break;
					
				case "2":						// Print Cart
					if (!(myOrder.isEmpty()))
					{
						if (myOrder.getCart() != null)			// Print Order Contents
						{
							System.out.println();
							System.out.println("Order Contents");
							Display.printCart(myOrder.getCart());
							System.out.println("Order Total: $" + String.format("%.2f", myOrder.getTotalCost()));
						}
						break;
					}
					else
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Order Empty");
						System.out.println("--------------------");
					}
										
					break;
					
				case "3":						// Remove an Item
					Item removed = myOrder.dequeue();
					if (removed != null)
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Removed Item");
						System.out.println("--------------------");
						Display.printItem(removed);
						System.out.println("--------------------");
					}
					else
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Order Empty");
						System.out.println("--------------------");
					}
					break;
					
				case "4":						// Wipe the Order
					if (myOrder.isEmpty() == false)
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Cleared Cart");
						Display.printCart(myOrder.clear());
					}
					else
					{
						System.out.println();
						System.out.println("--------------------");
						System.out.println("Order Empty");
						System.out.println("--------------------");
					}
					break;
					
				case "5":						// Done
					System.out.println();
					System.out.println("--------------------");
					System.out.println("Returning to Order Menu");
					System.out.println("--------------------");
					continue;
					
				default:
					System.out.println();
					System.out.println("--------------------");
					System.out.println("Invalid Entry. Try Again.");
					System.out.println("--------------------");
					break;
			
			}
		} while (!(choice.equals("5")));
		
		if (myOrder.getCart() != null)			// Print Order Contents
		{
			System.out.println();
			System.out.println("Order Contents");
			Display.printCart(myOrder.getCart());
			System.out.println("Order Total: $" + String.format("%.2f", myOrder.getTotalCost()));
			System.out.println();
		}
		
		return myOrder;
	}
}