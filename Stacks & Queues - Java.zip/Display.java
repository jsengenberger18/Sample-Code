package listPack;

public class Display
{
	// Order Arrays
	private static Order unsorted [] = null;
	private static Order byCustomer [] = null;
	private static Order byOrderNum [] = null;
	
	// Display Menus
	public static void showMainMenu()
	{
		System.out.println();
		System.out.println("Choose Menu Option");
		System.out.println("--------------------");
		System.out.println("(1) Add to Order");
		System.out.println("(2) New Order");
		System.out.println("(3) Show");
		System.out.println("(4) Remove");
		System.out.println("(5) Clear");
		System.out.println("(6) Quit");
		System.out.println("--------------------");
		System.out.print("Selection: ");
	}
	public static void showItemMenu()
	{
		System.out.println();
		System.out.println("Item Queue Options");
		System.out.println("--------------------");
		System.out.println("(1) Add Item");
		System.out.println("(2) Show Cart");
		System.out.println("(3) Remove Item");
		System.out.println("(4) Clear");
		System.out.println("(5) Done");
		System.out.println("--------------------");
		System.out.print("Selection: ");
	}
	public static void showProductMenu (Item [] productListing)
	{
		System.out.println();
		System.out.println("Select an Item");
		System.out.println();
		
		for (Item product : productListing)
		{
			printItem(product);
		}
		
		System.out.println();
		System.out.println("Enter 'Done' to Close");
		System.out.println("--------------------");
	}
	
	// Display Orders & Items
	public static void printOrderDB (Order front)
	{
		if (front != null)
		{
			System.out.println();
			System.out.println("Front");
			System.out.println("--------------------");
			System.out.println("--------------------");
			
			printOrder(front);
			printCart(front.getCart());
	
			while (front.getNextOrder() != null)
			{
				front = front.getNextOrder();

				System.out.println("--------------------");
				printOrder(front);
				printCart(front.getCart());
			}
			System.out.println("--------------------");
			System.out.println("Back");
			System.out.println("--------------------");
		}
		else
		{
			System.out.println();
			System.out.println("--------------------");
			System.out.println("Order Database Empty");
			System.out.println("--------------------");
		}
	}
	public static void printOrder (Order toPrint)
	{
		if (toPrint != null)
		{
			System.out.println("Order Number: " + toPrint.getOrderNum());
			System.out.println("Customer Name: " + toPrint.getCustomer());
			System.out.println("Order Total: " + String.format("%.2f", (toPrint.getTotalCost())));
		}
	}
	public static void printCart (Item front)
	{
		if (front != null)
		{
			System.out.println("--------------------");
			printItem(front);
	
			while (front.getNextItem() != null)
			{
				front = front.getNextItem();
				printItem(front);
			}
			System.out.println("--------------------");
		}
		else
		{
			System.out.println("--------------------");
			System.out.println("Empty Cart");
			System.out.println("--------------------");
		}
	}
	public static void printItem (Item toPrint)
	{
		if (toPrint != null)
		{
			System.out.print(toPrint.getItemName());
			System.out.print(" (" + toPrint.getQuantity() + ") ");
			System.out.print("- $" + String.format("%.2f", (toPrint.getQuantity() * toPrint.getPrice())));
			System.out.println();
		}
	}
	
	// Display Order Arrays
	public static void printUnsortedOrders ()
	{
		System.out.println("Unsorted Orders");
		System.out.println("--------------------");
		
		for (Order orders : unsorted)
		{
			System.out.println();
			System.out.println("Order Number: " + orders.getOrderNum());
			System.out.println("Customer Name: " + orders.getCustomer());
			System.out.println("Order Total: " + String.format("%.2f", (orders.getTotalCost())));
		}
		
		System.out.println();
		System.out.println("--------------------");
	}
	public static void printByCustomer()
	{
		System.out.println("Sorted by Customer");
		System.out.println("--------------------");
		
		for (Order orders : byCustomer)
		{
			System.out.println();
			System.out.println("Customer Name: " + orders.getCustomer());
			System.out.println("Order Number: " + orders.getOrderNum());
			System.out.println("Order Total: " + String.format("%.2f", (orders.getTotalCost())));
		}
		
		System.out.println();
		System.out.println("--------------------");
	}
	public static void printByOrderNum()
	{
		System.out.println("Sorted by Order Number");
		System.out.println("--------------------");
		
		for (Order orders : byOrderNum)
		{
			System.out.println();
			System.out.println("Order Number: " + orders.getOrderNum());
			System.out.println("Order Total: " + String.format("%.2f", (orders.getTotalCost())));
			System.out.println("Customer Name: " + orders.getCustomer());
		}
		
		System.out.println();
		System.out.println("--------------------");
	}
	
	// Sort Orders
	public static void sortOrders(OrderQueue customerOrders)
	{
		unsorted = customerOrders.toArray();
		byCustomer = customerOrders.toArray();
		byOrderNum = customerOrders.toArray();
		
		if (checkSorted (unsorted, true) == false)		// Customer
		{
			quickSortCustomer(0, unsorted.length - 1);
		}
		
		if (checkSorted (unsorted, false) == false)		// Order Number
		{
			quickSortOrderNum(0, unsorted.length - 1);
		}
	}
	public static boolean checkSorted (Order [] orderDB, boolean byCustomer)
	{
		boolean sorted = true;
		int index = 0;
		
		while (sorted == true && index < orderDB.length - 1)
		{
			if (byCustomer == true)
			{
				if (orderDB [index].getCustomer().compareTo(orderDB [index + 1].getCustomer()) < 0)
				{
					sorted = false;
				}
			}
			else
			{
				if (orderDB [index].getOrderNum() < orderDB [index + 1].getOrderNum())
				{
					sorted = false;
				}
			}
			
			index++;
		}
		
		return sorted;
	}
	public static void quickSortCustomer (int begin, int end)
	{
		int lower = begin;
		int upper = end;
		
		if (upper - lower >= 1)
		{
			String pivot = byCustomer[lower].getCustomer();
		
			while (upper > lower)
			{
				while ((byCustomer[lower].getCustomer().compareTo(pivot) >= 0 && lower < end && lower <= upper))
				{
					lower++;
				}
				while ((byCustomer[upper].getCustomer().compareTo(pivot) <= 0 && upper > begin && upper >= lower))
				{
					upper--;
				}
				if (upper > lower)
				{
					Order temp = byCustomer[lower];
					byCustomer[lower] = byCustomer[upper];
					byCustomer[upper] = temp;
				}
			}
			
			Order temp = byCustomer[begin];
			byCustomer[begin] = byCustomer[upper];
			byCustomer[upper] = temp;
			
			quickSortCustomer(begin, upper - 1);
			quickSortCustomer(upper + 1, end);
		}
	}
	public static void quickSortOrderNum (int begin, int end)
	{
		int lower = begin;
		int upper = end;
		
		if (upper - lower >= 1)
		{
			int pivot = byOrderNum[lower].getOrderNum();
		
			while (upper > lower)
			{
				while ((byOrderNum[lower].getOrderNum() >= pivot && lower < end && lower <= upper))
				{
					lower++;
				}
				while ((byOrderNum[upper].getOrderNum() <= pivot && upper > begin && upper >= lower))
				{
					upper--;
				}
				if (upper > lower)
				{
					Order temp = byOrderNum[lower];
					byOrderNum[lower] = byOrderNum[upper];
					byOrderNum[upper] = temp;
				}
			}
			
			Order temp = byOrderNum[begin];
			byOrderNum[begin] = byOrderNum[upper];
			byOrderNum[upper] = temp;
			
			quickSortOrderNum(begin, upper - 1);
			quickSortOrderNum(upper + 1, end);
		}
	}
}
