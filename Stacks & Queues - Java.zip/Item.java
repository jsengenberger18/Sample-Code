package listPack;

public class Item
{
	// Item Contents
	private String itemName;
	private double price;
	private int quantity;
	
	// Queue Links
	private Item nextItem;		// Front -> Back
	
	// Constructors
	protected Item (Item newItem)
	{
		itemName = newItem.getItemName();
		price = newItem.getPrice();
		quantity = newItem.getQuantity();
		
		nextItem = null;
	}
	protected Item (double inPrice, String inName)
	{
		itemName = inName;
		price = inPrice;
		quantity = 1;
		
		nextItem = null;
	}
	
	// Getters
	protected String getItemName()
	{
		return itemName;
	}
	protected double getPrice()
	{
		return price;
	}
	protected int getQuantity()
	{
		return quantity;
	}
	protected Item getNextItem()
	{
		return nextItem;
	}
	
	// Setters
	protected void setNextItem(Item nextNode)
	{
		nextItem = nextNode;
	}
	
	// Miscellaneous
	protected void incrementQuantity()
	{
		quantity++;
	}
}
