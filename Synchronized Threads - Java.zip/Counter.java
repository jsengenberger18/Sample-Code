package threading_final;

class Counter
{
	protected static final int MAX = 20;
	protected static final int MIN = 0;
	
	protected static final boolean UP = true;
	protected static final boolean DOWN = false;
	
	private static boolean direction;
	private static int count;
	
	// Constructors
	protected Counter (boolean startDir, int startNum)
	{
		direction = startDir;		
		setCount(startNum);
	}
	
	// Getters
	protected synchronized boolean getDirection ()
	{
		return direction;
	}
	protected synchronized int getCount ()
	{
		return count;
	}
	
	// Setters
	protected synchronized void setDirection (boolean startDir)
	{
		direction = startDir;
	}
	protected synchronized void setCount (int startNum)
	{
		// Keep MIN / MAX Bounds
		if (startNum < MIN)
		{
			System.out.println();
			System.out.println("Start Too Low - Default: MIN");
			startNum = MIN;
		}
		else if (startNum > MAX)
		{
			System.out.println();
			System.out.println("Start Too High - Default: MAX");
			startNum = MAX;
		}
		
		count = startNum;
	}
	
	// Increments to MAX or Decrements to MIN depending on current direction
	protected synchronized void count ()
	{
		if (direction == UP)
		{
			System.out.println();
			System.out.print(count);
			
			while (count < MAX)
			{
				count++;
				System.out.print(" - " + count);
			}
			
			System.out.println();
			System.out.println();
			System.out.println ("MAX Reached");
			
			direction = DOWN;
		}
		else
		{
			System.out.println();
			System.out.print(count);
			
			while (count > MIN)
			{
				count--;
				System.out.print(" - " + count);
			}
			
			System.out.println();
			System.out.println();
			System.out.println ("MIN Reached");
			
			direction = UP;
		}
	}

}