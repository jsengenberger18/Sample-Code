package threading_final;

class MyThread extends Thread
{
	Counter thisCount;
	
	protected MyThread (Counter toSync)
	{
		thisCount = toSync;
	}
	
	@Override
	public void run ()
	{
		try
		{
			thisCount.count();
		}
		catch (Exception e)
		{
			System.out.println ("Thread Interrupted - " + e.getMessage());
			
			try
			{
				this.join();
			}
			catch (Exception e2)
			{
				System.out.println ("Join Interrupted - " + e2.getMessage());
			}
		}
	}
}