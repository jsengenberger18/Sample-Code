/*
 * SynchronizedCounting.java
 *
 *  Created on: Oct 31, 2022
 *  Completed on: Nov 20, 2022
 *      Author: Justin Sengenberger
 */

package threading_final;
import java.util.Scanner;

class SynchronizedCounting
{
	public static void main (String[] args)
	{
		try
		{
			// Declare Input Variables
			boolean direction;
			int countStart;
			
			// Request User Input
			Scanner scnr = new Scanner (System.in);
			try
			{
				direction = retrieveDirection (scnr);
				countStart = retrieveStartNum (scnr);
				
				scnr.close();
			}
			catch (Exception e)
			{
				scnr.close();

				// Error on Failed Input
				System.out.println();
				System.out.println("User Input Error: " + e.getMessage());
				System.out.println("Executing Default - Increment from Zero");
				System.out.println();
				
				// Assume starting UP from MIN
				direction = Counter.UP;
				countStart = Counter.MIN;
			}
			
			// Initialize Counters
			Counter toSync = new Counter (direction, countStart);
			
			// Initialize Threads
			MyThread t1 = new MyThread (toSync);
			MyThread t2 = new MyThread (toSync);
			
			// Start Threads
			t1.start();
			t2.start();
			
			// Join Threads
			try
			{
				t1.join();
				t2.join();
			}
			catch (Exception e)
			{
				System.out.println ("Join Interrupted");
			}			
		}
		catch (Exception e)
		{
			System.out.println ("Program Error - " + e.getMessage());
		}
	}
	
	// User Input
	// Retrieves the directionality of the counter from the user
	private static boolean retrieveDirection (Scanner scnr) throws Exception
	{		
		String userInput;
		boolean direction;
		
		try
		{
			System.out.print ("Do you want to count up to start? Enter Y/N: ");
			userInput = scnr.next();
			
			// Check Input
			switch (userInput.charAt(0))
			{
				case 'N':
				case 'n':
					direction = Counter.DOWN;
					break;
				case 'Y':
				case 'y':
					direction = Counter.UP;
					break;
					
				default:
					throw new Exception ("(Y)es or (N)o Required");
			}
			
			return direction;
		}
		catch (Exception e)
		{
			throw new Exception ("Invalid Choice: " + e.getMessage());			
		}
	}
	
	// Retrieves the counter's start number from the user
	private static int retrieveStartNum (Scanner scnr) throws Exception
	{
		String userInput;
		String toInt = "";
		boolean neg = false;
		
		try
		{
			System.out.print ("Enter a number within " + Counter.MIN + " and " + Counter.MAX + " to start the counter: ");
			userInput = scnr.next();
			
			// Check First Character
			if (userInput.charAt(0) == '-')
			{
				neg = true;
			}
			else if (Character.isDigit(userInput.charAt(0)) == false)
			{
				throw new Exception ("Pos 0");
			}
			else
			{
				toInt += userInput.charAt(0);
			}
			
			// Check Second Character
			if (userInput.length() > 1)
			{
				if (Character.isDigit(userInput.charAt(1)) == false)
				{
					throw new Exception ("Pos 1");
				}
				else
				{
					toInt += userInput.charAt(1);
				}
				
				// Check Third Character (if negative)
				if (neg == true && userInput.length() > 2)
				{
					if (Character.isDigit(userInput.charAt(2)) == false)
					{
						throw new Exception ("Pos 2");
					}
					else
					{
						toInt += userInput.charAt(2);
					}
				}
			}
			
			// Perform Conversion
			int startNum = Integer.parseInt(toInt);
			
			if (neg == true)
				startNum = startNum * -1;
			
			return startNum;
		}
		catch (Exception e)
		{
			System.out.println();
			throw new Exception ("Invalid Value: " + e.getMessage());
		}
	}
}