#ifndef ASSEMPROJ_H
#define ASSEMPROJ_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

/*************************/
const int MAX = 350;  //size of simulators memor
const bool DEBUG = false;
/*************************/






const int COL = 7;	 //number of columns for output

const int SPECIAL = 0;
const int BRK = 3;  //calls a function
const int IRET = 4; //returns from a function
const int HALT = 5;
const int GET = 6;
const int PUT = 7;

const int JUMP = 1;
const int NOT = 2;
const int COMPARE =  96;
const int OR = 32;
const int AND = 64;
const int CMP = 96;    //011 00 000
const int SUB = 128;
const int ADD = 160;


const int MOVEREG = 192;	//110 00 000
const int MOVETOMEM = 224;	//111 00 000

const int DREF = 7;  //derefernce BX = [[BX]]
const int JMP = 6;
const int JAE = 5;
const int JA = 4;
const int JBE = 3;
const int JB = 2;
const int JNE = 1;
const int JE = 0;

const int ARRAYBX = 4;
const int ARRAYSTRUCT = 5;
const int ARRAYBXPLUS = 5;   //second name for same thing
const int ADDRESSINMEM = 6;
const int CONSTANT = 7;

	//REGISTERS
const int REG1AX = 0;
const int REG1BX = 1;
const int REG1CX = 2;
const int REG1DX = 3;
/* special commands spring 16*/
const int SWAP = 3;   //added special S16
const int MUL = 0;
const int DIV = 1;
const int PMT = 2;
typedef short int Memory;   //creates a new type so we are not using short int over and over.  If the program changes so memory needs to be larger only the typedef needs to change
enum paramType { reg, mem, constant, arrayBx, arrayBxPlus, none };
//global variable:

struct Registers   // the 6 different types of registers
{
	int AX;
	int BX;
	int CX;
	int DX;
	int instrAddr;  //what line of code when the program in running
	int flag;  //compare flag
} regis;  // a global variable containing the current registers.




int address;  //current address being created or ran 
extern Memory memory[MAX] = {0};  //all of memory, used and modified by most functions  
string pmtArray[20];  //array for prompts
int stackPtr = MAX - 1;

//prototypes
void printMemoryDump(); //prints memeory with integers commands

//	//converting
void convertToNumber(string line, int &start, int &value);  //takes in a string and changes it to number
void fillMemory();  //prepares to move the file into memory
void changeToLowerCase(string &line);  //makes sure everything is in lower case
Memory  findRegister(string line, int &startLoc);//fill memory find a register number

//running
int createCommand(int command, paramType  twoType, int twoValue);  //puts together a line of machine code
int whichReg(char regLetter);  //determines the register

/* helper functions*/
void operand(string line, int &start, paramType &type, int &value);  //determines the operand in an command
int getValueFromRegis(int currentRegister);
int whichReg(char regLetter);
void putValueInRegis(int currentRegister, int value);

/* convert to machine code functions*/
void movToMemFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue);
void movFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue);
void addFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue);
void compareFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue);
void jumpFunc(string line, int jumpToAddress);
void getFunc(int value);
void putFunc(int value);
void subFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue);
void brkFunc(ifstream &fin);
void iretfunc();

/* run machine code functions*/
void runPut();
void runGet();
void runGet();
void runMoveToMem();
void runMoveRegular();
void runAdd();
void runCompare();
void runJump();
int pmtFunc(string line);
void runSub();  //*****only works for positive numbers 
void runBrk(int returnAddress);
void runIret();

#endif