#pragma once
#include "assemBase.h"

void runPmt()
{
	int promptNumber;
	regis.instrAddr++;
	promptNumber = memory[regis.instrAddr] ;
	cout <<pmtArray[promptNumber]<<endl;
	
}
/************************************************************************
puts together a full line of code as machine language.
************************************************************************/
void convertToMachineCode(ifstream &fin)
{
	string line;
	getline(fin, line, '\n');
	if (line[0] == '/' || line[0] == '\\')  //skip comments
	{
		return;
	}
	paramType oneType, twoType;  //the types of the two operands
	int oneValue, twoValue;  //the actual values of the two operands
	if (line.size() > 0)
	{
		//cout<<address<<"the line is "<<line<<endl;
		changeToLowerCase(line);
		int start = 4;
		if (start < line.size())  //get the first operand
		{
			operand(line, start, oneType, oneValue);
		}
		if (start < line.size())  //get the second operand
		{
			operand(line, start, twoType, twoValue);
		}

		switch (line[0])
		{
		case 'a':
			if (line[1] == 'd') addFunc(oneType, oneValue, twoType, twoValue);
			else { ; }//andFun(oneType, oneValue, twoType, twoValue)
			break;
		case 'b': brkFunc(fin);//brk  call function
			break;
		case 'c':  compareFunc(oneType, oneValue, twoType, twoValue);//compare
			break;
		case 'g':  getFunc(oneValue);
			break;
		case 'h':  	memory[address] = HALT;//halt
			break;
		case 'i':  iretfunc();
			break;
		case 'j':  jumpFunc(line, oneValue);    //only one jump value//jump
			break;
		case 'm':
			if (line[1] == 'u')
			{
				//*****Multiplyfunc(oneType, oneValue, twoType, twoValue);
			}
			else if (line[4] == '[')
			{
				movToMemFunc(oneType, oneValue, twoType, twoValue);
			}
			else
			{
				movFunc(oneType, oneValue, twoType, twoValue);
			}
			break;
		case 'n':  //not
			break;
		case 'o':  //or
			break;
		case 'p':
			if (line[1] == 'u')  //put funciton
			{
				putFunc(oneValue);//put
			}
			else
			{
				getline(fin, line, '\n');
				pmtFunc(line);  //prompt
			}

			break;

		case 's':  subFunc(oneType, oneValue, twoType, twoValue);//subtract
			break;
		default:  //it must be a number
			start = 0;
			convertToNumber(line, start, oneValue);
			memory[address] = oneValue;
		}
	}
	//cout<<memory[address]<<endl;
	address++;
}

/*************************************************************
the function that runs the program.
**************************************************************/
void runProgram()
{
	int value = memory[regis.instrAddr];
	int command;   //the part of the command being evaluated
	while (value != HALT)  //halts the program
	{
		if (value > 31)
		{
			command = value & 224;   //the top three bits
			if (command == OR)
			{
				//runOr();
			}
			else if (command == AND)
			{
				//runAnd();
			}
			else if (command == CMP)
			{
				runCompare();
			}
			else if (command == SUB)
			{
				runSub();
			}
			else if (command == ADD)
			{
				runAdd();
			}
			else if (command == MOVEREG)
			{
				runMoveRegular();
			}
			else if (command == MOVETOMEM)
			{
				runMoveToMem();
			}
		}
		else  if (value > 7)  //single operand
		{
			command = (value & 24) >> 3;  //bits 3 & 4
			if (command > 0)
			{
				if (command == JUMP)
				{
					runJump();
				}
				else if (command == NOT)
				{
					//runNot();
				}
				else if (command == SWAP)
				{
					//runSwap();
				}
			}
		}
		else //lower command
		{
			command = value & 7;  //bottom 3 bits
			if (command == PMT)
			{
				runPmt();
			}
			if (command == PUT)
			{
				runPut();
			}
			else if (command == GET)
			{
				runGet();
			}
			else if (command == BRK)
			{
				runBrk(regis.instrAddr);
			}
			else if (command == IRET)
			{
				runIret();
			}
			else if (command == 0)
			{
				cout << " there is an error the command is 0";
			}
		}
		if (DEBUG == true)
		{
			printMemoryDump();
			system("pause");
		}

		regis.instrAddr++;
		value = memory[regis.instrAddr];		
	}
}

int main()
{
	regis.instrAddr = 0;

	fillMemory();
	cout << "Here is the memory before run\n";
	printMemoryDump();
	system("pause");
	runProgram();   //needs to be created by student; // runs the machine code that was created
	cout << "\n\nMemory dump after run\n";
	printMemoryDump();


	system("pause");
	return 0;
}
/********************************************************************
Displays all of the memory in good columns.
MAX is the amount of elements in the memory array
COL is the number of columns that are to be displayed
*********************************************************************/
void printMemoryDump()
{
	int numRows = MAX / COL + 1; //number of rows to output
	int carryOver = MAX%COL; //number of columns on the bottom row
	int location; //the current location being called
	cout << setw(3);

	for (int row = 0; row < numRows; row++)
	{
		location = row;
		for (int column = 0; location < MAX&&column < COL; column++)
		{
			if (!(numRows - 1 == row&&carryOver - 1 < column))
			{
				cout << location << "." << setw(5) << memory[location] << setw(5);
				location += (numRows - (carryOver - 1 < column));
			}
		}
		cout << endl;
		cout << setw(3);
	}

	cout << endl;
	cout << "AX: " << regis.AX << '\t';
	cout << "BX: " << regis.BX << '\t';
	cout << "CX: " << regis.CX << '\t';
	cout << "DX: " << regis.DX << '\t';
	cout << endl << endl;
	cout << "Instruction: " << regis.instrAddr <<"\t\t";
	cout << "Flag: " << regis.flag<<"\t\t";
	cout << "stack pointer" << stackPtr;

	cout << endl << endl;
}

/********************************************************
changes the substring into an integer
*********************************************************/
void convertToNumber(string line, int &start, int &value)
{
	char number[16];
	bool negative = false;
	//	cout<< "in convertToNumber before function 1  start is "<<start<<endl;
	int i = 0;
	if (line[start] == '-')
	{
		start++;
		negative = true;
	}
	while (i<16 && line.size() > start&& isdigit(line[start]))
	{
		number[i] = line[start];
		//	cout<<line[start];
		i++;
		start++;
		//		cout<<i<<start;
	}
	number[i] = '\0';
	value = atoi(number);
	if (negative == true)
	{
		value = -value;
	}
	//	cout<< "in convertToNumber after function 1  start is "<<start<<endl;
}

/*******************************************************************
changes all letters to the same case, lower case
********************************************************************/
void changeToLowerCase(string &line)
{
	unsigned int index = 0;
	while (index < line.size())
	{
		line[index] = tolower(line[index]);
		index++;
	}
	//	cout<<"the line in change"<<line;

}
//fill memory find a register number
Memory  findRegister(string line, int &startLoc)
{
	int xLoc;
	Memory reg = -10;
	xLoc = line.find('x', startLoc);
	cout << xLoc;
	if (xLoc > 0)
	{
		/* space before x convert to number - a */
		reg = int(line[xLoc - 1]) - int('a');
		startLoc = xLoc + 1;   // move to the next possible part of the command
	}
	return reg;
}
void fillMultiply(string line)
{
	cout << "***** multiply not done";
}



/*******************************************************************
Get the file and prepare to move the file into the assembler memory.
********************************************************************/
void fillMemory()
{
	string line;
	int value = 0;
	cout << "Enter the assembly file name.  No spaces. filename.asm  ";
	cin >> line;
	address = 0;
	ifstream fin;
	fin.open(line);
	if (fin.fail())
	{
		cout << "Error, file didn't open\n";
		system("pause");
		exit(1);
	}

	while (!fin.fail())
	{
		
		//cout<<"*"<<line<<"*"<<endl;
		convertToMachineCode(fin);

	}
}

/*helper functions*/
void operand(string line, int &start, paramType &type, int &value)  //determines the operand in an command
{
	int start1 = start;
	//	cout<<line<<"line.size() "<<line.size()<<"start "<<start<<endl;
	//	cout<<"in operand "<<line[start]<<endl;

	if (start >= line.size())
	{
		type = none;
		value = 0;
	}
	else if (isalpha(line[start]))  //reg
	{
		type = reg;
		value = whichReg(line[start]);
	}
	else if (line[start] == '[')  //an address 
	{

		int plusLoc = line.find("+");
		if (plusLoc == string::npos)  //constant that means it isn't in the string (-1)
		{
			start++;  //move past the beginning [
			if (isalpha(line[start]))  //we have a letter so bx 
			{
				type = arrayBx;
				value = 1;  //no value needed but set to 1 just in case	
			}
			else // memory address
			{
				type = mem;
				convertToNumber(line, start, value);
			}
		}
		else //there is a plus
		{

			type = arrayBxPlus;
			start++;
			convertToNumber(line, start, value);
		}

		//		cout<< "in operand after convert to number memory start is "<<start<<endl;

	}
	else  //must be a constant
	{
		type = constant;
		convertToNumber(line, start, value);
		//		cout<< "in operand after convert to number constant start is "<<start<<endl;
	}
	while (start < line.size() && line[start] != ' ')
	{
		start++;
	}
	start++;  //get past space
}


int getValueFromRegis(int currentRegister)
{
	if (currentRegister == REG1DX)
	{
		return regis.DX;
	}
	else if (currentRegister == REG1CX)
	{
		return regis.CX;
	}
	else if (currentRegister == REG1BX)
	{
		return regis.BX;
	}
	else
	{
		return regis.AX;
	}
}

int whichReg(char regLetter)
{
	if (regLetter == 'a')
	{
		return 0;
	}
	else if (regLetter == 'b')
	{
		return 1;
	}
	else if (regLetter == 'c')
	{
		return 2;
	}
	else if (regLetter == 'd')
	{
		return 3;
	}
	return -1;  //if this happens there has been a major problem
}

void putValueInRegis(int currentRegister, int value)
{
	if (currentRegister == REG1DX)
	{
		regis.DX = value;
	}
	else if (currentRegister == REG1CX)
	{
		regis.CX = value;
	}
	else if (currentRegister == REG1BX)
	{
		regis.BX = value;
	}
	else if (currentRegister == REG1AX)
	{
		regis.AX = value;
	}
}

int createCommand(int command, paramType twoType, int twoValue) /*puts together a command**/
{
	if (twoType == reg)
	{
		command += twoValue;
		memory[address] = command;
	}
	else if (twoType == constant)
	{
		command = command + CONSTANT;
		memory[address] = command;
		address++;
		memory[address] = twoValue;
	}
	else if (twoType == mem)
	{
		command = command + ADDRESSINMEM;
		memory[address] = command;
		address++;
		memory[address] = twoValue;
	}
	else if (twoType == arrayBxPlus)
	{
		command = command + ARRAYBXPLUS;
		memory[address] = command;
		address++;
		memory[address] = twoValue;

	}
	else if (twoType == arrayBx)
	{
		command = command + ARRAYBX;
		memory[address] = command;
	}
	return command;
}

/********************************************************
creating machine code functions
*********************************************************/
void movToMemFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue)
{
	int command = MOVETOMEM;

	if (currentRegisterType == none || twoType == none)
	{
		cout << "ERROR in add, type is none" << address;
		system("pause");
		exit(1);
	}
	command = command + (twoValue << 3);
	command = createCommand(command, currentRegisterType, oneValue);

}

void movFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue)
{
	int command;
	if (twoValue == 4)
	{
		cout << "here";
	}
	//	cout<<" in moveFunc currentRegister "<<currentRegisterType<<" twoType "<<twoType<<endl;
	if (currentRegisterType == none || twoType == none || currentRegisterType == constant)
	{
		cout << "ERROR  in move, type is none" << address;
		system("pause");
		exit(1);
	}

	if (currentRegisterType == reg)
	{
		command = MOVEREG + (oneValue << 3);
		if (twoType == reg)
		{
			command = command + twoValue;
			memory[address] = command;
		}
		else if (twoType == constant)
		{
			command = command + 7;
			memory[address] = command;
			address++;
			memory[address] = twoValue;
		}
		else if (twoType == mem)
		{
			command = command + 6;
			memory[address] = command;
			address++;
			memory[address] = twoValue;
		}
		else if (twoType == arrayBxPlus)
		{
			command = command + 5;
			memory[address] = command;
			address++;
			memory[address] = twoValue;

		}
		else if (twoType == arrayBx)
		{
			command = command + 4;
			memory[address] = command;
		}
	}
	else if (currentRegisterType == mem)
	{
		command = MOVETOMEM + (twoValue << 3) + 6;
		memory[address] = command;
		address++;
		memory[address] = oneValue;
	}
	else if (currentRegisterType == arrayBx)
	{
		command = MOVETOMEM + (twoValue << 3) + 4;
		memory[address] = command;
	}
	else if (currentRegisterType == arrayBxPlus)
	{
		command = MOVETOMEM + (twoValue << 3) + 5;
		memory[address] = command;
		address++;
		memory[address] = oneValue;
	}
}

void addFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue) /**/
{
	int command = ADD;
	if (currentRegisterType == none || twoType == none)
	{
		cout << "ERROR in add, type is none" << address;
		system("pause");
		exit(1);
	}
	command = command + (oneValue << 3);
	command = createCommand(command, twoType, twoValue);
}

void compareFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue)
{
	int command = COMPARE;
	if (currentRegisterType == none || twoType == none)
	{
		cout << "ERROR  in compare, type is none" << address;
		system("pause");
		exit(1);
	}
	command = command + (oneValue << 3);
	command = createCommand(command, twoType, twoValue);
}

void jumpFunc(string line, int jumpToAddress)
{
	int command = JUMP << 3;
	if (line[1] == 'e')  //equal
	{
		command += JE;
	}
	else if (line[1] == 'n')  //Not equal
	{
		command += JNE;
	}
	else if (line[1] == 'b')  //Not equal
	{
		if (line[2] == 'e')
		{
			command += JBE;
		}
		else
		{
			command += JB;
		}
	}
	else if (line[1] == 'a')  //Not equal
	{
		if (line[2] == 'e')
		{
			command += JAE;
		}
		else
		{
			command += JA;
		}
	}
	else if (line[1] == 'm')  //Not equal
	{
		command += JMP;
	}
	memory[address] = command;
	address++;
	memory[address] = jumpToAddress;

}

void getFunc(int value)
{
	memory[address] = GET;
	address++;
	memory[address] = value;
}

void putFunc(int value)
{
	memory[address] = PUT;
	address++;
	memory[address] = value;
}

void subFunc(paramType currentRegisterType, int oneValue, paramType  twoType, int twoValue)
{
	int command = SUB;
	if (currentRegisterType == none || twoType == none)
	{
		cout << "ERROR  in add, type is none" << address;
		system("pause");
		exit(1);
	}
	command = command + (oneValue << 3);
	command = createCommand(command, twoType, twoValue);

}

void brkFunc(ifstream &fin)
{
	string line;
	int start = 0;
	int value = 0;

	memory[address] = BRK;   // the break command
	address++;	
	getline(fin, line, '\n');
	start = 1;

	convertToNumber(line, start, value);
	memory[address] = value;			//the address of the function
	address++;
	getline(fin, line, '\n');
	start = 0;
	convertToNumber(line, start, value);
	memory[address] = value;		//the number of parameters
	address++;
	int count = value;
	for (int i = 0; i < count; i++)
	{
		getline(fin, line, '\n');
		start = 1;
		convertToNumber(line, start, value);
		memory[address] = value;			//getting the parameters
		address++;
	}
	address--;
}


void iretfunc()
{
	memory[address] = IRET;
}
/********************************************************
running machine code functions
*********************************************************/
void runPut()
{
	regis.instrAddr++;
	cout << "\n\nOutput " << memory[memory[regis.instrAddr]] << "\n\n";
}

void runGet()
{
	int value;
	cout << "enter value ";
	cin >> value;
	regis.instrAddr++;
	memory[memory[regis.instrAddr]] = value;
}

void runMoveToMem()
{

	int currentRegister = (memory[regis.instrAddr] & 24) >> 3; //11000 first operand
	int value = memory[regis.instrAddr];  //number in the memory location
	int placementAddress = -1;				//location of result
	int junk = memory[regis.instrAddr] & ADDRESSINMEM;
	if ((memory[regis.instrAddr] & ADDRESSINMEM) == ADDRESSINMEM)
	{
		regis.instrAddr++;
		placementAddress = memory[regis.instrAddr];
	}
	else if ((memory[regis.instrAddr] & ARRAYBXPLUS) == ARRAYBXPLUS)
	{
		regis.instrAddr++;
		placementAddress = regis.BX + memory[regis.instrAddr];
	}
	else if ((memory[regis.instrAddr] & ARRAYBX) == ARRAYBX)
	{
		placementAddress = regis.BX;
		//cout<<regis.instrAddr;
	}
	if (placementAddress > MAX || placementAddress < 0)  //out of memeory range
	{
		cout << "off the end of memory in runMoveToMem or error";
		system("pause");
		exit(1);
	}
	memory[placementAddress] = getValueFromRegis(currentRegister);
	int value2 = memory[placementAddress];
}

void runMoveRegular()
{
	int currentRegister = (memory[regis.instrAddr] & 24) >> 3; //11000 first operand
	int secondoperand = memory[regis.instrAddr] & 7; //111 second operand

	if (secondoperand < 4) //reg to reg
	{
		putValueInRegis(currentRegister, getValueFromRegis(secondoperand));
	}
	else
	{

		if (secondoperand == CONSTANT)
		{
			regis.instrAddr++;
			putValueInRegis(currentRegister, memory[regis.instrAddr]);

			//cout<<"put in reg "<<regis.CX;
		}
		else if (secondoperand == ADDRESSINMEM)  // memory
		{
			regis.instrAddr++;
			int hold = memory[regis.instrAddr];
			putValueInRegis(currentRegister, memory[hold]);
		}
		else if (secondoperand == ARRAYBXPLUS)
		{
			regis.instrAddr++;
			int hold = memory[regis.instrAddr];
			putValueInRegis(currentRegister, (memory[regis.BX + hold]));
		}
		else if (secondoperand == ARRAYBX)
		{
			putValueInRegis(currentRegister, memory[regis.BX]);
		}
	}
}

void runAdd()
{
	int currentRegister = ((memory[regis.instrAddr] & 24) >> 3); //11000 first operand
	int secondoperand = memory[regis.instrAddr] & 7; //111 second operand
	int value2 = 0;		//second paramters value
	if (secondoperand < 4)
	{
		value2 = getValueFromRegis(secondoperand);
	}
	else if (secondoperand == CONSTANT)  //
	{
		regis.instrAddr++;
		value2 = memory[regis.instrAddr];
		//cout<<"value "<<value2;
		//system("pause");
	}
	else if (secondoperand == ADDRESSINMEM)//memory location
	{
		regis.instrAddr++;
		value2 = memory[memory[regis.instrAddr]];
	}
	int value1 = getValueFromRegis(currentRegister);
	putValueInRegis(currentRegister, value1 + value2);
}

void runCompare()
{
	int value = memory[regis.instrAddr];
	int currentRegister = (memory[regis.instrAddr] & 24) >> 3; //11000 first operand
	int secondoperand = memory[regis.instrAddr] & 7; //111 second operand
	int value1;
	int value2 = -1;		//second paramters value
	value1 = getValueFromRegis(currentRegister);
	if (secondoperand < 4)
	{
		value2 = getValueFromRegis(secondoperand);
	}
	else if (secondoperand == CONSTANT)  //
	{
		regis.instrAddr++;
		value2 = memory[regis.instrAddr];
		//cout<<"value "<<value2;
		//system("pause");
	}
	else if (secondoperand == 4)//memory location
	{
		regis.instrAddr++;
		value2 = memory[memory[regis.instrAddr]];
	}
	regis.flag = 1;
	if (value1 < value2)
	{
		regis.flag = -1;
	}
	else if (value1 == value2)
	{
		regis.flag = 0;
	}

}

void runJump()
{
	int whichJump = memory[regis.instrAddr] & 7;  //just get the last 3 bits
	regis.instrAddr++;
	int jumpTo = memory[regis.instrAddr];    //inst reg not moved becasue of jump away
	if (whichJump == JMP)  //always jump
	{
		regis.instrAddr = jumpTo;
	}
	else if (whichJump == JE && regis.flag == 0)
	{
		regis.instrAddr = jumpTo;
	}
	else if (whichJump == JNE && regis.flag != 0)
	{
		regis.instrAddr = jumpTo;
	}
	else if (regis.flag <= 0 && (whichJump == JBE)) //equal  
	{
		regis.instrAddr = jumpTo;
	}
	else if (regis.flag == -1 && (whichJump == JB)) //below
	{
		regis.instrAddr = jumpTo;
	}
	else if (regis.flag == 1 && (whichJump == JA)) //above
	{
		regis.instrAddr = jumpTo;
	}
	else if (regis.flag >= 1 && (whichJump == JAE)) //above
	{
		regis.instrAddr = jumpTo;
	}
	else
	{
		regis.instrAddr++;
	}
	regis.instrAddr--;  //back one so in can be incremented in run program

}

void runSub()  //*****only works for positive numbers  
{
	int currentRegister = ((memory[regis.instrAddr] & 24) >> 3); //11000 first operand
	int secondoperand = memory[regis.instrAddr] & 7; //111 second operand
	int value2 = 0;		//second paramters value
	if (secondoperand < 4)
	{
		value2 = getValueFromRegis(secondoperand);
	}
	else if (secondoperand == CONSTANT)  //
	{
		regis.instrAddr++;
		value2 = memory[regis.instrAddr];

	}
	else if (secondoperand == ADDRESSINMEM)//memory location
	{
		regis.instrAddr++;
		value2 = memory[memory[regis.instrAddr]];
	}
	int value1 = getValueFromRegis(currentRegister);
	putValueInRegis(currentRegister, value1 - value2);
}

int pmtFunc(string line)  //*** put comamnd in memory
{
	static int pmtAddress = 0;  //current address for the pr
	memory[address] = PMT;
	address++;
	memory[address] = pmtAddress;
	pmtArray[pmtAddress] = line;
	pmtAddress++;
	return pmtAddress - 1;
}

void runBrk(int returnAddress)
{
	memory[stackPtr] = regis.AX;
	stackPtr--;
	memory[stackPtr] = regis.BX;
	stackPtr--;
	memory[stackPtr] = regis.CX;
	stackPtr--;
	memory[stackPtr] = regis.DX;
	stackPtr--;
	memory[stackPtr] = regis.flag;
	stackPtr--;
	memory[stackPtr] = returnAddress;
	regis.BX = returnAddress + 3;
	printMemoryDump();
	regis.instrAddr = memory[returnAddress+1] - 1; // need to be one less because of the addtion
}

void runIret()
{
	
	int funcAddr;
	funcAddr = memory[stackPtr];  //return address

	regis.instrAddr = funcAddr + memory[funcAddr + 2] + 2;  //move past address, and parameters
	stackPtr++;
	regis.flag = memory[stackPtr];
	stackPtr++;
	regis.DX = memory[stackPtr];
	stackPtr++;
	regis.CX = memory[stackPtr];
	stackPtr++;
	regis.BX = memory[stackPtr];
	stackPtr++;
	regis.AX = memory[stackPtr];
	
}